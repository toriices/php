<?php

function checkBoard($board, $symbol) {
  $row0 = $board[0][0] === $symbol && $board[0][1] === $symbol && $board[0][2] === $symbol;
  $row1 = $board[1][0] === $symbol && $board[1][1] === $symbol && $board[1][2] === $symbol;
  $row2 = $board[2][0] === $symbol && $board[2][1] === $symbol && $board[2][2] === $symbol;
  $col0 = $board[0][0] === $symbol && $board[1][0] === $symbol && $board[2][0] === $symbol;
  $col1 = $board[0][1] === $symbol && $board[1][1] === $symbol && $board[2][1] === $symbol;
  $col2 = $board[0][2] === $symbol && $board[1][2] === $symbol && $board[2][2] === $symbol;
  $diagLR = $board[0][0] === $symbol && $board[1][1] === $symbol && $board[2][2] === $symbol;
  $diagRL = $board[0][2] === $symbol && $board[1][1] === $symbol && $board[2][0] === $symbol;
  return ($row0 || $row1 || $row2 || $col0 || $col1 || $col2 || $diagLR || $diagRL);
}

session_start();
require "vendor/autoload.php";

use eftec\bladeone\BladeOne;

$views = __DIR__ . '\views';
$cache = __DIR__ . '\cache';
$blade = new BladeOne($views, $cache, BladeOne::MODE_DEBUG);

$BOARD_SIZE = 3;
$PATH_PLAYER_PIC = './public/assets/img/circle.jpg';
$PATH_COMPUTER_PIC = './public/assets/img/cross.jpeg';



if (empty($_POST)) {
  $_SESSION['board'] = array(
    array('', '', ''),
    array('', '', ''),
    array('', '', ''),
  );
  
  echo $blade->run('move', ["BOARD_SIZE" => $BOARD_SIZE, "PATH_PLAYER_PIC" => $PATH_PLAYER_PIC, "PATH_COMPUTER_PIC" => $PATH_COMPUTER_PIC]);
} else {
  $board = $_SESSION['board'];
  $x = filter_input(INPUT_POST, "x", FILTER_VALIDATE_INT);
  $y = filter_input(INPUT_POST, "y", FILTER_VALIDATE_INT);
  $board[$x][$y] = "o";
  $playerWin = checkBoard($board, 'o');
  $draw = true;
  foreach ($board as $row) {
    foreach ($row as $cell) {
      if ($cell === '') {
        $draw = false;
        break;
      }
    }
    if (!$draw) {
      break;
    }
  }

  if ($playerWin) {
    session_destroy();
    $response = array('gameRes' => 1);
    echo json_encode($response);
  } elseif ($draw) {
    session_destroy();
    $response = array('gameRes' => 0);
    echo json_encode($response);
  } else {
    $computerPlay = true;
    $errorOccurred = false;
    $availableSpaces = 0;

    foreach ($board as $row) {
        foreach ($row as $cell) {
            if ($cell === '') {
                $availableSpaces++;
            }
        }
    }

    while ($computerPlay && !$errorOccurred) {
        if ($availableSpaces === 0) {
            $errorOccurred = true;
            break;
        }

        $rowComp = rand(0, 2);
        $colComp = rand(0, 2);
        if ($board[$rowComp][$colComp] === '') {
            $board[$rowComp][$colComp] = 'x';
            $computerPlay = false;
            $availableSpaces--;
        }
    }

    if ($errorOccurred) {
        $response = array('error' => 'Error en el juego: no se pueden realizar más movimientos.');
        echo json_encode($response);
    } elseif (checkBoard($board, 'x')) {
        session_destroy();
        $response = array(
            'x' => $rowComp,
            'y' => $colComp,
            'gameRes' => -1
        );
        echo json_encode($response);
    } else {
        $_SESSION['board'] = $board;
        $response = array(
            'x' => $rowComp,
            'y' => $colComp
        );
        echo json_encode($response);
    }
  }
}

?>
