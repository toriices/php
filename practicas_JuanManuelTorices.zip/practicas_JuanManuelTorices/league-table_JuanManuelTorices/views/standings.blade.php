<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Clasificación Final</title>
</head>
<body>
    <h1>Clasificación Final de la Liga</h1>
    <table border="1">
        <tr>
            <th>Equipo</th>
            <th>Puntos</th>
            <th>Goles Marcados</th>
            <th>Goles Encajados</th>
            <th>Diferencia de Goles</th>
        </tr>
        @foreach($standings as $team => $data)
            <tr>
                <td>{{ $team }}</td>
                <td>{{ $data['points'] }}</td>
                <td>{{ $data['scored'] }}</td>
                <td>{{ $data['conceded'] }}</td>
                <td>{{ $data['scored'] - $data['conceded'] }}</td>
            </tr>
        @endforeach
    </table>
</body>
</html>
