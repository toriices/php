@extends('app')
@section('title', 'Adivine el número')
@section('content')
<form class="form-font" name="form_config" action="index.php" method="POST">
  <div class="form-section">
    <label for="min">Límite inferior:</Label> 
    <input readonly value="{{$min}}" id="min" type="number"  required name="min" min="0"/> 
  </div>
  <div class="form-section">
    <label for="max">Límite superior:</Label> 
    <input readonly value="{{$max}}" id="max" type="number"  required name="max" min="1"/> 
  </div>
  <div class="form-section">
    <label for="intentos">Número de intentos:</Label> 
    <input readonly value="{{$intentos}}" id="intentos" type="number"  required name="intentos" min="1"/> 
  </div>
  <div class="form-section">
    <label for="adivina">Introduzca un número:</Label> 
    <input autofocus value="{{$adivina}}" id="adivina" type="number"  name="adivina" min="1"/> 
  </div>
  @if (!empty($mensaje))
  <p class="info-section">{{$mensaje}}</p>
  @endif
  <div class="submit-section-2">
    <input class="reset" type="submit" value="Reiniciar" name="Reiniciar"/>
    <input class="submit" type="submit" value="Adivinar" name="Adivinar"/>
  </div>
</form>

@endSection

