@extends('app')
@section('title', 'Fin')
@section('content')
<form class="form-font" name="form_config" action="index.php" method="POST">
  <h1>{{$mensaje}}</h1>
  <div class="submit-section-2">
    <input class="reset" type="submit" value="Reiniciar" name="Reiniciar"/>
  </div>
</form>
@endSection

