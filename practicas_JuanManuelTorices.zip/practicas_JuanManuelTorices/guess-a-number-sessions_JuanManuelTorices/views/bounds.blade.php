@extends('app')
@section('title', 'Configuración')
@section('content')
<form class="form-font" name="form_config" 
      action="index.php" method="POST">
    <div class="form-section">
        <label for="min">Límite inferior:</Label> 
        <input autofocus id="min" value="{{$min}}" type="number"  name="min" min="0"/> 
    </div>
    <div class="form-section">
        <label for="max">Límite superior:</Label> 
        <input id="max" value="{{$max}}" type="number"  name="max" min="1"/> 
    </div>
    <div class="form-section">
        <label for="intentos">Intentos:</Label> 
        <input id="intentos" value="{{$intentos}}" type="number"  name="intentos" min="1"/> 
    </div>
    @if (!empty($mensaje))
    <p class="info-section">{!! $mensaje !!}</p>
    @endif
    <div class="submit-section-2">
        <input class="submit" type="submit" 
               value="Configurar" name="Configurar" /> 
    </div>
</form>   
@endSection