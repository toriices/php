<?php
session_start();
require "vendor/autoload.php";
require "GuessNumber.php";

use App\GuessNumber;
use eftec\bladeone\BladeOne;

$views = __DIR__ . '/views';
$cache = __DIR__ . '/cache';
$blade = new BladeOne($views, $cache, BladeOne::MODE_DEBUG); 

if (isset($_POST['Reiniciar'])) {
    session_destroy();
    session_start(); 
    echo $blade->run('bounds', ['mensaje' => '']);
} elseif (isset($_POST['Configurar'])) {
    $min = filter_input(INPUT_POST, 'min', FILTER_VALIDATE_INT);
    $max = filter_input(INPUT_POST, 'max', FILTER_VALIDATE_INT);
    $intentos = filter_input(INPUT_POST, 'intentos', FILTER_VALIDATE_INT);
    
    if ($min !== false && $max !== false && $intentos !== false && $min < $max && $intentos > 0) {
        $juego = new GuessNumber($min, $max, $intentos);
        $_SESSION['juego'] = serialize($juego);
        echo $blade->run('game', [
            'min' => $min,
            'max' => $max,
            'intentos' => $intentos,
            'mensaje' => ''
        ]);
    } else {
        $mensaje = "Verifica los datos: El mínimo debe ser menor que el máximo, y el número de intentos debe ser positivo.";
        echo $blade->run('bounds', ['mensaje' => $mensaje]);
    }
} elseif (isset($_POST['Adivinar'])) {
    $juego = isset($_SESSION['juego']) ? unserialize($_SESSION['juego']) : null;
    $adivina = filter_input(INPUT_POST, 'adivina', FILTER_VALIDATE_INT);
    
    if ($juego && is_numeric($adivina)) {
        $resultado = $juego->comprobar($adivina);
        $mensajes = [
            'has ganado' => "¡Felicidades! Acertaste. El número era " . $juego->getSecreto(),
            'has perdido' => "Perdiste. No hay más intentos. El número era " . $juego->getSecreto(),
            'es mayor' => "El número secreto es mayor.",
            'es menor' => "El número secreto es menor.",
            'error' => "Por favor, introduce un número válido."
        ];

        $template = ($resultado === 'has ganado' || $resultado === 'has perdido') ? 'final' : 'game';
        echo $blade->run($template, [
            'mensaje' => $mensajes[$resultado],
            'min' => $juego->getMin(),
            'max' => $juego->getMax(),
            'intentos' => $juego->getIntentosRestantes(), 
            'adivina' => $adivina
        ]);
        $_SESSION['juego'] = serialize($juego);
    } else {
        echo $blade->run('game', [
            'mensaje' => "Por favor, introduce un número válido.",
            'min' => $juego ? $juego->getMin() : 0,
            'max' => $juego ? $juego->getMax() : 0,
            'intentos' => $juego ? $juego->getIntentosRestantes() : 0, 
        ]);
    }
} else {
    echo $blade->run('bounds', ['mensaje' => '']);
}
