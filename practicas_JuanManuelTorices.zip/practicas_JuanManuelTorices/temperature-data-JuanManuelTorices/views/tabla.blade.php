@extends('app')
@section('title', 'Formulario para ingresar límites en el juego de adivinar un número')
@section('content')
<form class="form-font capaform" name="form_bounds" action="index.php" method="POST">
    <div class="flex-outer">
        @foreach($ciudades as $ciudad)
        <div class="tabla">
            <h2>{{ $ciudad }}</h2>
            <table>
                <tr>
                    <th>Mes</th>
                    <th>Mínimo</th>
                    <th>Máximo</th>
                </tr>
                @foreach($meses as $mes)
                <tr>
                    <td>{{ $mes }}</td>
                    <td>
                        <input type="number" name="temperaturas[{{ $ciudad }}][{{ $mes }}][min]" value="{{$temperaturas[$ciudad][$mes]['minima']}}">
                    </td>
                    <td>
                        <input type="number" name="temperaturas[{{ $ciudad }}][{{ $mes }}][max]" value="{{$temperaturas[$ciudad][$mes]['maxima']}}">
                    </td>
                </tr>
                @endforeach
            </table>
        </div>
        @endforeach    
    </div>
    <div class="submit-section">
        <input class="submit" type="submit" value="Enviar" name="tablaButton" />
    </div>
</form>
@endSection
