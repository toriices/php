@extends('app')
@section('title', 'Form to enter bounds for guess a number Game')
@section('content')
<form class="form-font capaform" name="form_bounds" action="index.php" method="POST">
    <div class="flex-outer">
        <div class="form-section">
            <label for="lowerbound">Ciudades:</Label>
            <textarea name="ciudades" id="ciudades" cols="50" rows="5">{{ $texto }}</textarea>
            <span class="error">{{ $error }}</span>
        </div>
        
        <div class="submit-section">
            <input class="submit" type="submit" value="Send" name="boundsbutton" />
        </div>
        
    </div>
</form>
@endSection